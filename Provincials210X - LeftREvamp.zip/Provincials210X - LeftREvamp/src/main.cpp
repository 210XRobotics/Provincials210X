#include "main.h"

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */



void initialize() {
  std::cout << "initialize ran" << std::endl;

  LGyro.reset();
  RGyro.reset();

  pros::delay(2000);

  LGyro.set_heading(0);
  RGyro.set_heading(0);


  //piston inits
  retractpiston.set_value(false);
  tpiston.set_value(true);
  clawpiston.set_value(true);

  setDriveCoast();
}



/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {
  // . . .
}



/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {
  // . . .
  //piston inits
  // retractpiston.set_value(false);
  // tpiston.set_value(true);

}



/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void progskills() {
  ptopiston.set_value(true);
  tpiston.set_value(false);

  translate(-1550, 12000, true);
  pros::delay(200);
  retractpiston.set_value(true);

  translate(-1400, 12000, true);
  clawpiston.set_value(false);
  pros::delay(200);
  rotate(135, 1, true);

  translate(1500, 12000, true);
  clawpiston.set_value(true);
  rotate(90, -1, true);
  translate(1000, 12000, true);
  /*
  lttmotor.set_value(127);
  rttmotor.set_value(127);
  pros::delay(500);

  lttmotor.set_brake_mode(pros::E_BRAKE_MODE_HOLD);
  rttmotor.set_brake_mode(pros::E_BRAKE_MODE_HOLD);

  lttmotor.set_value(0);
  rttmotor.set_value(0);*/

  rotate(90, 1, true);

  clawpiston.set_value(true);
}


void shogotogo() {
  ptopiston.set_value(false);
  tpiston.set_value(true);
    
  translate(-1000, 12000, false);

  setAutoMotors(0, 0, false);
  pros::delay(100);

  retractpiston.set_value(true);

  translate(500, 12000, false);
  pros::delay(100);
  clawpiston.set_value(false);
  //rotate(-90, 6000, false);
  setAutoMotors(0, 0, false);
  pros::delay(1000);
  
  rotate(142.5, 1, false);

  //grab middle
  translate(1550, 10000, false);
  clawpiston.set_value(true);
  pros::delay(200);
  translate(-1200, 10000, false);
  
}

void leftshogo() {
  ptopiston.set_value(false);
  tpiston.set_value(true);

  translate(-1350, 12000, false);
  pros::delay(100);

  retractpiston.set_value(true);

  translate(500, 12000, false);
  pros::delay(100);
  rotate(90, 1, false);
  rotate(90, 1, false);
  setAutoMotors(0, 0, false);

  clawpiston.set_value(false);
}

void autonomous() {
  //rotate(90, 1, false);
  // shogotogo();
  leftshogo();
}


/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {
  std::cout << "opcontrol ran" << std::endl;

  //Gyro testcode
  // LGyro.set_heading(0);
  // RGyro.set_heading(0);
  // int avggyro = 0;

  setDriveCoast();

	bool bpto = false;
	bool btransmission = true;
	bool frontclaw = true;
	bool hold = false;
	bool retract = false;

  // int correction = 0;
  // int mult = 20;

	while (true) {

		//transmission & pto
    //printf("LIMU yaw: %f\n", LGyro.get_yaw())
		if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_L2))
		{
			btransmission = !btransmission;
			tpiston.set_value(btransmission);
		}

		if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_B))
		{
			bpto = !bpto;
			ptopiston.set_value(bpto);
		}

		if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_L1))
		{
			frontclaw = !frontclaw;
			clawpiston.set_value(frontclaw);
		}

    if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_X))
		{
			retract = !retract;
			retractpiston.set_value(retract);
		}

    if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_UP))
		{
			hold = !hold;
			if (hold){
        setDriveHold();
      }
      else{
        setDriveCoast();
      }
		}

		setDrive(bpto, hold);
		setLift(bpto);

    /*
    std::cout << "LGyro : " << LGyro.get_heading() << "   RGyro : " << RGyro.get_heading() << "   CORR : " << correction << std::endl;
    
    if (avggyro > 180){
      correction = -(360-avggyro);
    } 
    else{
      correction = (avggyro);
    }


    avggyro = (LGyro.get_heading()+(RGyro.get_heading()))/2;
    
    //Gyro test
    */
    pros::delay(10);
	}
}
