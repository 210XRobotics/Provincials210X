#include "main.h"

void setDriveMotors(int left, int right, bool pto)
{
  lbbmotor = left;
  lbtmotor = left;
  ltbmotor = left;

  rbbmotor = right;
  rbtmotor = right;
  rtbmotor = right;

  if (!pto) {
    rttmotor = right;
    lttmotor = left;
  }
}

void setDrive(bool pto, bool hold)
{
  //getting joystick elements
  int rightJoy = master.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
  int leftJoy = master.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_X);

  if (hold)
  {
    rightJoy*=0.7;
    leftJoy*=0.7;
  }


  //setting drive motors
  setDriveMotors((rightJoy-leftJoy), (rightJoy+leftJoy), pto);
}

//auton functions

//autonomous functions

void setAutoMotors(int left, int right, bool pto)
{
  lbbmotor.move_voltage(left);
  lbtmotor.move_voltage(left);
  ltbmotor.move_voltage(left);

  rbbmotor.move_voltage(right);
  rbtmotor.move_voltage(right);
  rtbmotor.move_voltage(right);

  if (!pto) {
    rttmotor.move_voltage(right);
    lttmotor.move_voltage(left);
  }
}

void resetDrive()
{
  lbbmotor.tare_position();
  rbbmotor.tare_position();
}

float avgencoder()
{
  return (fabs(lbbmotor.get_position())+
  fabs(rbbmotor.get_position()))/2;
}

void translate(int units, int voltage, bool pto)
{
  LGyro.set_heading(0); RGyro.set_heading(0);

  int dir = abs(units)/units;
  int avggyro = (LGyro.get_heading()+(RGyro.get_heading()))/2;
  int correction = 0; //change value to tune responsiveness
  int mult = 0;

  resetDrive();

  while(fabs(avgencoder())<fabs(units))
  {
    avggyro = ((LGyro.get_heading()+(RGyro.get_heading()))/2);

    // range of get heading is 1 degree to 359
    if (avggyro > 180){
      correction = -(360 - avggyro) * mult;
    } 
    else{
      correction = (avggyro) * mult;
    }

    setAutoMotors(voltage*dir + correction, voltage*dir - correction, pto);
    pros::delay(10);
  }

  setAutoMotors(-10*dir, -10*dir, pto);
  pros::delay(50);

  setAutoMotors(0, 0, pto);
}


float looparound(int degrees)
{
  float pi = 3.141592653589793238462643383279502884;
  return 180/pi*(atan2f(sinf(degrees*pi/180), cosf(degrees*pi/180)));
}

void rotate(int d, int direction,  bool pto)
{
  LGyro.set_heading(0); RGyro.set_heading(0);
  float degrees = looparound(d);

  //tuning values
  float kP = 100;
  float kI = 30;
  float kD = 990;

  float avggyro = looparound((LGyro.get_heading()+RGyro.get_heading())/2);

  float errors = degrees - avggyro;
  float preverror = errors;

  int cnt = 0;
  //first turn

  while (cnt < 8)
  {
    avggyro = looparound((LGyro.get_heading()+RGyro.get_heading())/2);

    errors = degrees - avggyro;
    errors = looparound(errors);

    std::cout<<"bruh<" << errors << std::endl;
    // - kD*(errors-preverror)     - kD*(errors-preverror)
    setAutoMotors(-(kP*(errors))*direction, (kP*(errors))*direction, pto);

    if (errors < 2 && errors > -2)
    {
      cnt+=1;
    }
    else{
      cnt = 0;
    }
    preverror = errors;
    pros::delay(10);
  }
  /*
  while (abs(avggyro) < abs(degrees)-15)
  {
    avggyro = (LGyro.get_yaw()+RGyro.get_yaw())/2;

    setAutoMotors(-voltage*direction, voltage*direction, pto);
    pros::delay(10);
  }

  pros::delay(200);

  int secondspeed = 0.7;
  LGyro.set_yaw(0); RGyro.set_yaw(0);
  degrees = degrees-avggyro;
  //correction turns
  while (abs(avggyro) < abs(degrees))
  {
    avggyro = (LGyro.get_yaw()+RGyro.get_yaw())/2;

    setAutoMotors(-voltage*direction*secondspeed, voltage*direction*secondspeed, pto);
    pros::delay(10);
  }

  while (abs(avggyro) > abs(degrees))
  {
    avggyro = (LGyro.get_yaw()+RGyro.get_yaw())/2;

    setAutoMotors(voltage*direction*secondspeed, -voltage*direction*secondspeed, pto);
    pros::delay(10);
  }


  setAutoMotors(0, 0, pto);
  pros::delay(10);

  pros::delay(100);

  

  /*
  if (fabs(avggyro/10) > abs(degrees))
  {
    while(fabs(avggyro/10) > abs(degrees))
    {
      avggyro = (LGyro.get_heading()+RGyro.get_heading())/2;

      setAutoMotors(-1*voltage*direction*0.3, voltage*direction*0.3, pto);
      pros::delay(10);
    }
  }

  else if (fabs(avggyro/10) < abs(degrees))
  {
    while(fabs(avggyro/10) < abs(degrees))
    {
      avggyro = (LGyro.get_heading()+RGyro.get_heading())/2;

      setAutoMotors(voltage*direction*0.3, -1*voltage*direction*0.3, pto);
      pros::delay(10);
    }
  }

  setAutoMotors(0, 0, pto);
  pros::delay(70);
  */
}


void setDriveHold()
{
  lttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  ltbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  lbtmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  lbbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  rttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  rtbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  rbtmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  rbbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
}

void setDriveCoast()
{
  lttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  ltbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  lbtmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  lbbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  rttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  rtbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  rbtmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  rbbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
}