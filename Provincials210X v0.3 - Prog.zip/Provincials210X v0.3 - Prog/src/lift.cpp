#include "main.h"

void setLift (bool pto)
{
    if (pto)
    {
        lttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
        rttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);

        int direction = 0;

        if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2))
        {
            direction++;
        }
        if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R1))
        {
            direction--;
        }

        lttmotor = 127*direction;
        rttmotor = 127*direction;
    }
    
    else {
        lttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
        rttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
    }
}

void setAutoLift (int speed, bool pto)
{
    if (pto)
    {
        lttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
        rttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);

        lttmotor = speed;
        rttmotor = speed;
    }
    
    else {
        lttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
        rttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
    }
}