#include "main.h"

void setLift(bool pto);

void setAutoLift(int speed, bool pto);