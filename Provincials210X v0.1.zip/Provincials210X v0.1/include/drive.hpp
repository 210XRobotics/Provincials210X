#include "main.h"

void setDriveMotors(int left, int right, bool pto);
void setDrive(bool pto);
void testset();

void translate(int units, int voltage, bool pto);
void rotate(int degrees, int voltage, bool pto);

void setDriveHold();
void setDriveCoast();
