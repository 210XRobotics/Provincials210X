#include "main.h"

void setDriveMotors(int left, int right, bool pto)
{
  lbbmotor = left;
  lbtmotor = left;
  ltbmotor = left;

  rbbmotor = right;
  rbtmotor = right;
  rtbmotor = right;

  if (!pto) {
    rttmotor = right;
    lttmotor = left;
  }
}

void setDrive(bool pto)
{
  //getting joystick elements
  int rightJoy = master.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
  int leftJoy = master.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_X);


  //setting drive motors
  setDriveMotors((rightJoy-leftJoy), (rightJoy+leftJoy), pto);
}

//auton functions

//autonomous functions

void setAutoMotors(int left, int right, bool pto)
{
  lbbmotor = left;
  lbtmotor = left;
  ltbmotor = left;

  rbbmotor = right;
  rbtmotor = right;
  rtbmotor = right;

  if (!pto) {
    rttmotor = right;
    lttmotor = left;
  }
}

void resetDrive()
{
  lbbmotor.tare_position();
  rbbmotor.tare_position();
}

float avgencoder()
{
  return (fabs(lbbmotor.get_position())+
  fabs(rbbmotor.get_position()))/2;
}

void translate(int units, int voltage, bool pto)
{
  int dir = abs(units)/units;
  int avggyro = (LGyro.get_yaw()-(RGyro.get_yaw()))/2;

  resetDrive();

  while(fabs(avgencoder())<fabs(units))
  {
    setAutoMotors(voltage*dir + avggyro, voltage*dir + avggyro, pto);
    pros::delay(10);
  }

  setAutoMotors(-10*dir, -10*dir, pto);
  pros::delay(50);

  setAutoMotors(0, 0, pto);
}

void rotate(int degrees, int voltage,  bool pto)
{
  int direction = abs(degrees)/degrees;

  LGyro.set_yaw(0);
  RGyro.set_yaw(0);
  int avggyro = (LGyro.get_yaw()-(RGyro.get_yaw()))/2;

  while(fabs(avggyro/10) < abs(degrees-5))
  {
    setAutoMotors(voltage*direction, -1*voltage*direction, pto);
    pros::delay(10);
  }

  pros::delay(100);

  if (fabs(avggyro/10) > abs(degrees))
  {
    while(fabs(avggyro/10) > abs(degrees))
    {
      setAutoMotors(-1*voltage*direction*0.3, voltage*direction*0.3, pto);
      pros::delay(10);
    }
  }

  else if (fabs(avggyro/10) < abs(degrees))
  {
    while(fabs(avggyro/10) < abs(degrees))
    {
      setAutoMotors(voltage*direction*0.3, -1*voltage*direction*0.3, pto);
      pros::delay(10);
    }
  }

  setAutoMotors(0, 0, pto);
  pros::delay(70);
}


void setDriveHold()
{
  lttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  ltbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  lbtmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  lbbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  rttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  rtbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  rbtmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  rbbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
}

void setDriveCoast()
{
  lttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  ltbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  lbtmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  lbbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  rttmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  rtbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  rbtmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
  rbbmotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);;
}